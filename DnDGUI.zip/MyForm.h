#pragma once

namespace Project1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^  tabControl1;
	private: System::Windows::Forms::TabPage^  generalPage;
	private: System::Windows::Forms::TabPage^  statsPage;

	private: System::Windows::Forms::ComboBox^  classDropDown;
	protected:



	private: System::Windows::Forms::ComboBox^  raceDropDown;

	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  nameTextBox;

	private: System::Windows::Forms::Label^  label1;

	private: System::Windows::Forms::Label^  sizeBox;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Label^  ageBox;
	private: System::Windows::Forms::ComboBox^  comboBox4;
	private: System::Windows::Forms::ComboBox^  comboBox3;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::ComboBox^  comboBox5;
	private: System::Windows::Forms::Label^  paragonBox;

	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::Label^  dietyBox;
	private: System::Windows::Forms::Label^  genderBox;
	private: System::Windows::Forms::Label^  alignmentDropDown;
	private: System::Windows::Forms::Label^  weightDropDown;
	private: System::Windows::Forms::Label^  heightDropDown;
	private: System::Windows::Forms::ComboBox^  levelDropDown;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  textBox5;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::TextBox^  textBox6;
	private: System::Windows::Forms::Label^  epicDestinyBox;
	private: System::Windows::Forms::Label^  speedBox;
	private: System::Windows::Forms::Label^  xpBox;
	private: System::Windows::Forms::ComboBox^  wisdomDropDown;
	private: System::Windows::Forms::ComboBox^  intelligenceDropDown;
	private: System::Windows::Forms::ComboBox^  dexterityDropDown;
	private: System::Windows::Forms::ComboBox^  constitutionDropDown;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::ComboBox^  strengthDropDown;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::ComboBox^  charismaDropDown;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::ComboBox^  maxHPDropdown;

	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::ComboBox^  currentHPDropDown;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::TextBox^  textBox7;
	private: System::Windows::Forms::TextBox^  textBox12;
	private: System::Windows::Forms::TextBox^  textBox11;
	private: System::Windows::Forms::TextBox^  textBox10;
	private: System::Windows::Forms::TextBox^  textBox9;
	private: System::Windows::Forms::TextBox^  textBox8;
	private: System::Windows::Forms::TextBox^  textBox18;
	private: System::Windows::Forms::TextBox^  textBox17;
	private: System::Windows::Forms::TextBox^  textBox16;
	private: System::Windows::Forms::TextBox^  textBox15;
	private: System::Windows::Forms::TextBox^  textBox14;
	private: System::Windows::Forms::TextBox^  textBox13;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::TabPage^  skillsPage;
	private: System::Windows::Forms::TextBox^  textBox49;
	private: System::Windows::Forms::TextBox^  textBox50;
	private: System::Windows::Forms::TextBox^  textBox51;
	private: System::Windows::Forms::TextBox^  textBox52;
	private: System::Windows::Forms::ComboBox^  comboBox21;
	private: System::Windows::Forms::ComboBox^  comboBox22;
	private: System::Windows::Forms::Label^  label32;
	private: System::Windows::Forms::Label^  label33;
	private: System::Windows::Forms::TextBox^  textBox45;
	private: System::Windows::Forms::TextBox^  textBox46;
	private: System::Windows::Forms::TextBox^  textBox47;
	private: System::Windows::Forms::TextBox^  textBox48;
	private: System::Windows::Forms::ComboBox^  comboBox19;
	private: System::Windows::Forms::ComboBox^  comboBox20;
	private: System::Windows::Forms::Label^  label30;
	private: System::Windows::Forms::Label^  label31;
	private: System::Windows::Forms::TextBox^  textBox41;
	private: System::Windows::Forms::TextBox^  textBox42;
	private: System::Windows::Forms::TextBox^  textBox43;
	private: System::Windows::Forms::TextBox^  textBox44;
	private: System::Windows::Forms::ComboBox^  comboBox17;
	private: System::Windows::Forms::ComboBox^  comboBox18;
	private: System::Windows::Forms::Label^  label28;
	private: System::Windows::Forms::Label^  label29;
	private: System::Windows::Forms::TextBox^  textBox31;
	private: System::Windows::Forms::TextBox^  textBox32;
	private: System::Windows::Forms::TextBox^  textBox33;
	private: System::Windows::Forms::TextBox^  textBox34;
	private: System::Windows::Forms::TextBox^  textBox35;
	private: System::Windows::Forms::TextBox^  textBox36;
	private: System::Windows::Forms::TextBox^  textBox37;
	private: System::Windows::Forms::TextBox^  textBox38;
	private: System::Windows::Forms::TextBox^  textBox39;
	private: System::Windows::Forms::TextBox^  textBox40;
	private: System::Windows::Forms::ComboBox^  comboBox12;
	private: System::Windows::Forms::ComboBox^  comboBox13;
	private: System::Windows::Forms::ComboBox^  comboBox14;
	private: System::Windows::Forms::ComboBox^  comboBox15;
	private: System::Windows::Forms::ComboBox^  comboBox16;
	private: System::Windows::Forms::Label^  label23;
	private: System::Windows::Forms::Label^  label24;
	private: System::Windows::Forms::Label^  label25;
	private: System::Windows::Forms::Label^  label26;
	private: System::Windows::Forms::Label^  label27;
	private: System::Windows::Forms::TextBox^  textBox19;
	private: System::Windows::Forms::TextBox^  textBox20;
	private: System::Windows::Forms::TextBox^  textBox21;
	private: System::Windows::Forms::TextBox^  textBox22;
	private: System::Windows::Forms::TextBox^  textBox23;
	private: System::Windows::Forms::TextBox^  textBox24;
	private: System::Windows::Forms::TextBox^  textBox25;
	private: System::Windows::Forms::TextBox^  textBox26;
	private: System::Windows::Forms::TextBox^  textBox27;
	private: System::Windows::Forms::TextBox^  textBox28;
	private: System::Windows::Forms::TextBox^  textBox29;
	private: System::Windows::Forms::TextBox^  textBox30;
	private: System::Windows::Forms::ComboBox^  comboBox6;
	private: System::Windows::Forms::ComboBox^  comboBox7;
	private: System::Windows::Forms::ComboBox^  comboBox8;
	private: System::Windows::Forms::ComboBox^  comboBox9;
	private: System::Windows::Forms::ComboBox^  comboBox10;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::Label^  label17;
	private: System::Windows::Forms::ComboBox^  comboBox11;
	private: System::Windows::Forms::Label^  label18;
private: System::Windows::Forms::Label^  modifierhalfmod;

	private: System::Windows::Forms::Label^  label20;
	private: System::Windows::Forms::Label^  label22;
private: System::Windows::Forms::Label^  label34;
private: System::Windows::Forms::Label^  label21;
private: System::Windows::Forms::Label^  label19;




	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->generalPage = (gcnew System::Windows::Forms::TabPage());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->classDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->currentHPDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->maxHPDropdown = (gcnew System::Windows::Forms::ComboBox());
			this->levelDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox5 = (gcnew System::Windows::Forms::ComboBox());
			this->raceDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->paragonBox = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->nameTextBox = (gcnew System::Windows::Forms::TextBox());
			this->dietyBox = (gcnew System::Windows::Forms::Label());
			this->genderBox = (gcnew System::Windows::Forms::Label());
			this->alignmentDropDown = (gcnew System::Windows::Forms::Label());
			this->epicDestinyBox = (gcnew System::Windows::Forms::Label());
			this->speedBox = (gcnew System::Windows::Forms::Label());
			this->ageBox = (gcnew System::Windows::Forms::Label());
			this->weightDropDown = (gcnew System::Windows::Forms::Label());
			this->heightDropDown = (gcnew System::Windows::Forms::Label());
			this->xpBox = (gcnew System::Windows::Forms::Label());
			this->sizeBox = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->statsPage = (gcnew System::Windows::Forms::TabPage());
			this->textBox12 = (gcnew System::Windows::Forms::TextBox());
			this->textBox11 = (gcnew System::Windows::Forms::TextBox());
			this->textBox10 = (gcnew System::Windows::Forms::TextBox());
			this->textBox9 = (gcnew System::Windows::Forms::TextBox());
			this->textBox8 = (gcnew System::Windows::Forms::TextBox());
			this->textBox18 = (gcnew System::Windows::Forms::TextBox());
			this->textBox17 = (gcnew System::Windows::Forms::TextBox());
			this->textBox16 = (gcnew System::Windows::Forms::TextBox());
			this->textBox15 = (gcnew System::Windows::Forms::TextBox());
			this->textBox14 = (gcnew System::Windows::Forms::TextBox());
			this->textBox13 = (gcnew System::Windows::Forms::TextBox());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->charismaDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->wisdomDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->intelligenceDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->dexterityDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->constitutionDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->strengthDropDown = (gcnew System::Windows::Forms::ComboBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->skillsPage = (gcnew System::Windows::Forms::TabPage());
			this->textBox49 = (gcnew System::Windows::Forms::TextBox());
			this->textBox50 = (gcnew System::Windows::Forms::TextBox());
			this->textBox51 = (gcnew System::Windows::Forms::TextBox());
			this->textBox52 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox21 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox22 = (gcnew System::Windows::Forms::ComboBox());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->textBox45 = (gcnew System::Windows::Forms::TextBox());
			this->textBox46 = (gcnew System::Windows::Forms::TextBox());
			this->textBox47 = (gcnew System::Windows::Forms::TextBox());
			this->textBox48 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox19 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox20 = (gcnew System::Windows::Forms::ComboBox());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->textBox41 = (gcnew System::Windows::Forms::TextBox());
			this->textBox42 = (gcnew System::Windows::Forms::TextBox());
			this->textBox43 = (gcnew System::Windows::Forms::TextBox());
			this->textBox44 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox17 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox18 = (gcnew System::Windows::Forms::ComboBox());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->textBox31 = (gcnew System::Windows::Forms::TextBox());
			this->textBox32 = (gcnew System::Windows::Forms::TextBox());
			this->textBox33 = (gcnew System::Windows::Forms::TextBox());
			this->textBox34 = (gcnew System::Windows::Forms::TextBox());
			this->textBox35 = (gcnew System::Windows::Forms::TextBox());
			this->textBox36 = (gcnew System::Windows::Forms::TextBox());
			this->textBox37 = (gcnew System::Windows::Forms::TextBox());
			this->textBox38 = (gcnew System::Windows::Forms::TextBox());
			this->textBox39 = (gcnew System::Windows::Forms::TextBox());
			this->textBox40 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox12 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox13 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox14 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox15 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox16 = (gcnew System::Windows::Forms::ComboBox());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->textBox19 = (gcnew System::Windows::Forms::TextBox());
			this->textBox20 = (gcnew System::Windows::Forms::TextBox());
			this->textBox21 = (gcnew System::Windows::Forms::TextBox());
			this->textBox22 = (gcnew System::Windows::Forms::TextBox());
			this->textBox23 = (gcnew System::Windows::Forms::TextBox());
			this->textBox24 = (gcnew System::Windows::Forms::TextBox());
			this->textBox25 = (gcnew System::Windows::Forms::TextBox());
			this->textBox26 = (gcnew System::Windows::Forms::TextBox());
			this->textBox27 = (gcnew System::Windows::Forms::TextBox());
			this->textBox28 = (gcnew System::Windows::Forms::TextBox());
			this->textBox29 = (gcnew System::Windows::Forms::TextBox());
			this->textBox30 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox6 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox7 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox8 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox9 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox10 = (gcnew System::Windows::Forms::ComboBox());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->comboBox11 = (gcnew System::Windows::Forms::ComboBox());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->modifierhalfmod = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->tabControl1->SuspendLayout();
			this->generalPage->SuspendLayout();
			this->statsPage->SuspendLayout();
			this->skillsPage->SuspendLayout();
			this->SuspendLayout();
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->generalPage);
			this->tabControl1->Controls->Add(this->statsPage);
			this->tabControl1->Controls->Add(this->skillsPage);
			this->tabControl1->Location = System::Drawing::Point(1, 0);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(509, 588);
			this->tabControl1->TabIndex = 0;
			// 
			// generalPage
			// 
			this->generalPage->Controls->Add(this->comboBox4);
			this->generalPage->Controls->Add(this->comboBox3);
			this->generalPage->Controls->Add(this->comboBox2);
			this->generalPage->Controls->Add(this->comboBox1);
			this->generalPage->Controls->Add(this->classDropDown);
			this->generalPage->Controls->Add(this->currentHPDropDown);
			this->generalPage->Controls->Add(this->maxHPDropdown);
			this->generalPage->Controls->Add(this->levelDropDown);
			this->generalPage->Controls->Add(this->comboBox5);
			this->generalPage->Controls->Add(this->raceDropDown);
			this->generalPage->Controls->Add(this->label13);
			this->generalPage->Controls->Add(this->label3);
			this->generalPage->Controls->Add(this->label12);
			this->generalPage->Controls->Add(this->label4);
			this->generalPage->Controls->Add(this->paragonBox);
			this->generalPage->Controls->Add(this->label2);
			this->generalPage->Controls->Add(this->textBox1);
			this->generalPage->Controls->Add(this->textBox3);
			this->generalPage->Controls->Add(this->textBox5);
			this->generalPage->Controls->Add(this->textBox4);
			this->generalPage->Controls->Add(this->textBox2);
			this->generalPage->Controls->Add(this->textBox6);
			this->generalPage->Controls->Add(this->nameTextBox);
			this->generalPage->Controls->Add(this->dietyBox);
			this->generalPage->Controls->Add(this->genderBox);
			this->generalPage->Controls->Add(this->alignmentDropDown);
			this->generalPage->Controls->Add(this->epicDestinyBox);
			this->generalPage->Controls->Add(this->speedBox);
			this->generalPage->Controls->Add(this->ageBox);
			this->generalPage->Controls->Add(this->weightDropDown);
			this->generalPage->Controls->Add(this->heightDropDown);
			this->generalPage->Controls->Add(this->xpBox);
			this->generalPage->Controls->Add(this->sizeBox);
			this->generalPage->Controls->Add(this->label1);
			this->generalPage->Location = System::Drawing::Point(4, 22);
			this->generalPage->Name = L"generalPage";
			this->generalPage->Padding = System::Windows::Forms::Padding(3);
			this->generalPage->Size = System::Drawing::Size(501, 562);
			this->generalPage->TabIndex = 0;
			this->generalPage->Text = L"General";
			this->generalPage->UseVisualStyleBackColor = true;
			this->generalPage->Click += gcnew System::EventHandler(this, &MyForm::tabPage1_Click);
			// 
			// comboBox4
			// 
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Location = System::Drawing::Point(13, 345);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(121, 21);
			this->comboBox4->TabIndex = 3;
			this->comboBox4->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::classDropDown_SelectedIndexChanged);
			// 
			// comboBox3
			// 
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Location = System::Drawing::Point(13, 301);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(121, 21);
			this->comboBox3->TabIndex = 3;
			this->comboBox3->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::classDropDown_SelectedIndexChanged);
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Location = System::Drawing::Point(13, 261);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(121, 21);
			this->comboBox2->TabIndex = 3;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::classDropDown_SelectedIndexChanged);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(13, 144);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 21);
			this->comboBox1->TabIndex = 3;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::classDropDown_SelectedIndexChanged);
			// 
			// classDropDown
			// 
			this->classDropDown->FormattingEnabled = true;
			this->classDropDown->Location = System::Drawing::Point(13, 104);
			this->classDropDown->Name = L"classDropDown";
			this->classDropDown->Size = System::Drawing::Size(121, 21);
			this->classDropDown->TabIndex = 3;
			this->classDropDown->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::classDropDown_SelectedIndexChanged);
			// 
			// currentHPDropDown
			// 
			this->currentHPDropDown->FormattingEnabled = true;
			this->currentHPDropDown->Location = System::Drawing::Point(412, 21);
			this->currentHPDropDown->Name = L"currentHPDropDown";
			this->currentHPDropDown->Size = System::Drawing::Size(57, 21);
			this->currentHPDropDown->TabIndex = 3;
			this->currentHPDropDown->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::raceDropDown_SelectedIndexChanged);
			// 
			// maxHPDropdown
			// 
			this->maxHPDropdown->FormattingEnabled = true;
			this->maxHPDropdown->Location = System::Drawing::Point(339, 22);
			this->maxHPDropdown->Name = L"maxHPDropdown";
			this->maxHPDropdown->Size = System::Drawing::Size(57, 21);
			this->maxHPDropdown->TabIndex = 3;
			this->maxHPDropdown->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::raceDropDown_SelectedIndexChanged);
			// 
			// levelDropDown
			// 
			this->levelDropDown->FormattingEnabled = true;
			this->levelDropDown->Location = System::Drawing::Point(245, 23);
			this->levelDropDown->Name = L"levelDropDown";
			this->levelDropDown->Size = System::Drawing::Size(57, 21);
			this->levelDropDown->TabIndex = 3;
			this->levelDropDown->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::raceDropDown_SelectedIndexChanged);
			// 
			// comboBox5
			// 
			this->comboBox5->FormattingEnabled = true;
			this->comboBox5->Location = System::Drawing::Point(179, 105);
			this->comboBox5->Name = L"comboBox5";
			this->comboBox5->Size = System::Drawing::Size(121, 21);
			this->comboBox5->TabIndex = 3;
			this->comboBox5->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::raceDropDown_SelectedIndexChanged);
			// 
			// raceDropDown
			// 
			this->raceDropDown->FormattingEnabled = true;
			this->raceDropDown->Location = System::Drawing::Point(13, 64);
			this->raceDropDown->Name = L"raceDropDown";
			this->raceDropDown->Size = System::Drawing::Size(121, 21);
			this->raceDropDown->TabIndex = 3;
			this->raceDropDown->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::raceDropDown_SelectedIndexChanged);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(410, 5);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(59, 13);
			this->label13->TabIndex = 2;
			this->label13->Text = L"Current HP";
			this->label13->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(11, 88);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(32, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Class";
			this->label3->Click += gcnew System::EventHandler(this, &MyForm::label3_Click);
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(337, 6);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(45, 13);
			this->label12->TabIndex = 2;
			this->label12->Text = L"Max HP";
			this->label12->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(243, 7);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(33, 13);
			this->label4->TabIndex = 2;
			this->label4->Text = L"Level";
			this->label4->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// paragonBox
			// 
			this->paragonBox->AutoSize = true;
			this->paragonBox->Location = System::Drawing::Point(176, 88);
			this->paragonBox->Name = L"paragonBox";
			this->paragonBox->Size = System::Drawing::Size(72, 13);
			this->paragonBox->TabIndex = 2;
			this->paragonBox->Text = L"Paragon Path";
			this->paragonBox->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(10, 47);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(33, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Race";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(14, 385);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(123, 20);
			this->textBox1->TabIndex = 1;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(14, 222);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(123, 20);
			this->textBox3->TabIndex = 1;
			this->textBox3->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(179, 63);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(123, 20);
			this->textBox5->TabIndex = 1;
			this->textBox5->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(179, 145);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(123, 20);
			this->textBox4->TabIndex = 1;
			this->textBox4->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(14, 183);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(123, 20);
			this->textBox2->TabIndex = 1;
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(179, 24);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(53, 20);
			this->textBox6->TabIndex = 1;
			this->textBox6->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// nameTextBox
			// 
			this->nameTextBox->Location = System::Drawing::Point(13, 24);
			this->nameTextBox->Name = L"nameTextBox";
			this->nameTextBox->Size = System::Drawing::Size(123, 20);
			this->nameTextBox->TabIndex = 1;
			this->nameTextBox->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// dietyBox
			// 
			this->dietyBox->AutoSize = true;
			this->dietyBox->Location = System::Drawing::Point(11, 369);
			this->dietyBox->Name = L"dietyBox";
			this->dietyBox->Size = System::Drawing::Size(31, 13);
			this->dietyBox->TabIndex = 0;
			this->dietyBox->Text = L"Deity";
			this->dietyBox->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// genderBox
			// 
			this->genderBox->AutoSize = true;
			this->genderBox->Location = System::Drawing::Point(11, 206);
			this->genderBox->Name = L"genderBox";
			this->genderBox->Size = System::Drawing::Size(42, 13);
			this->genderBox->TabIndex = 0;
			this->genderBox->Text = L"Gender";
			this->genderBox->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// alignmentDropDown
			// 
			this->alignmentDropDown->AutoSize = true;
			this->alignmentDropDown->Location = System::Drawing::Point(11, 329);
			this->alignmentDropDown->Name = L"alignmentDropDown";
			this->alignmentDropDown->Size = System::Drawing::Size(53, 13);
			this->alignmentDropDown->TabIndex = 0;
			this->alignmentDropDown->Text = L"Alignment";
			this->alignmentDropDown->Click += gcnew System::EventHandler(this, &MyForm::sizeBox_Click);
			// 
			// epicDestinyBox
			// 
			this->epicDestinyBox->AutoSize = true;
			this->epicDestinyBox->Location = System::Drawing::Point(176, 47);
			this->epicDestinyBox->Name = L"epicDestinyBox";
			this->epicDestinyBox->Size = System::Drawing::Size(66, 13);
			this->epicDestinyBox->TabIndex = 0;
			this->epicDestinyBox->Text = L"Epic Destiny";
			this->epicDestinyBox->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// speedBox
			// 
			this->speedBox->AutoSize = true;
			this->speedBox->Location = System::Drawing::Point(176, 129);
			this->speedBox->Name = L"speedBox";
			this->speedBox->Size = System::Drawing::Size(38, 13);
			this->speedBox->TabIndex = 0;
			this->speedBox->Text = L"Speed";
			this->speedBox->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// ageBox
			// 
			this->ageBox->AutoSize = true;
			this->ageBox->Location = System::Drawing::Point(11, 167);
			this->ageBox->Name = L"ageBox";
			this->ageBox->Size = System::Drawing::Size(26, 13);
			this->ageBox->TabIndex = 0;
			this->ageBox->Text = L"Age";
			this->ageBox->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// weightDropDown
			// 
			this->weightDropDown->AutoSize = true;
			this->weightDropDown->Location = System::Drawing::Point(11, 285);
			this->weightDropDown->Name = L"weightDropDown";
			this->weightDropDown->Size = System::Drawing::Size(41, 13);
			this->weightDropDown->TabIndex = 0;
			this->weightDropDown->Text = L"Weight";
			this->weightDropDown->Click += gcnew System::EventHandler(this, &MyForm::sizeBox_Click);
			// 
			// heightDropDown
			// 
			this->heightDropDown->AutoSize = true;
			this->heightDropDown->Location = System::Drawing::Point(11, 245);
			this->heightDropDown->Name = L"heightDropDown";
			this->heightDropDown->Size = System::Drawing::Size(38, 13);
			this->heightDropDown->TabIndex = 0;
			this->heightDropDown->Text = L"Height";
			this->heightDropDown->Click += gcnew System::EventHandler(this, &MyForm::sizeBox_Click);
			// 
			// xpBox
			// 
			this->xpBox->AutoSize = true;
			this->xpBox->Location = System::Drawing::Point(174, 7);
			this->xpBox->Name = L"xpBox";
			this->xpBox->Size = System::Drawing::Size(21, 13);
			this->xpBox->TabIndex = 0;
			this->xpBox->Text = L"XP";
			this->xpBox->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// sizeBox
			// 
			this->sizeBox->AutoSize = true;
			this->sizeBox->Location = System::Drawing::Point(11, 128);
			this->sizeBox->Name = L"sizeBox";
			this->sizeBox->Size = System::Drawing::Size(27, 13);
			this->sizeBox->TabIndex = 0;
			this->sizeBox->Text = L"Size";
			this->sizeBox->Click += gcnew System::EventHandler(this, &MyForm::sizeBox_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(8, 7);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(35, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Name";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// statsPage
			// 
			this->statsPage->Controls->Add(this->textBox12);
			this->statsPage->Controls->Add(this->textBox11);
			this->statsPage->Controls->Add(this->textBox10);
			this->statsPage->Controls->Add(this->textBox9);
			this->statsPage->Controls->Add(this->textBox8);
			this->statsPage->Controls->Add(this->textBox18);
			this->statsPage->Controls->Add(this->textBox17);
			this->statsPage->Controls->Add(this->textBox16);
			this->statsPage->Controls->Add(this->textBox15);
			this->statsPage->Controls->Add(this->textBox14);
			this->statsPage->Controls->Add(this->textBox13);
			this->statsPage->Controls->Add(this->textBox7);
			this->statsPage->Controls->Add(this->charismaDropDown);
			this->statsPage->Controls->Add(this->wisdomDropDown);
			this->statsPage->Controls->Add(this->intelligenceDropDown);
			this->statsPage->Controls->Add(this->dexterityDropDown);
			this->statsPage->Controls->Add(this->constitutionDropDown);
			this->statsPage->Controls->Add(this->label10);
			this->statsPage->Controls->Add(this->label9);
			this->statsPage->Controls->Add(this->label8);
			this->statsPage->Controls->Add(this->strengthDropDown);
			this->statsPage->Controls->Add(this->label7);
			this->statsPage->Controls->Add(this->label14);
			this->statsPage->Controls->Add(this->label6);
			this->statsPage->Controls->Add(this->label11);
			this->statsPage->Controls->Add(this->label5);
			this->statsPage->Location = System::Drawing::Point(4, 22);
			this->statsPage->Name = L"statsPage";
			this->statsPage->Padding = System::Windows::Forms::Padding(3);
			this->statsPage->Size = System::Drawing::Size(501, 562);
			this->statsPage->TabIndex = 1;
			this->statsPage->Text = L"Stats";
			this->statsPage->UseVisualStyleBackColor = true;
			// 
			// textBox12
			// 
			this->textBox12->Location = System::Drawing::Point(79, 229);
			this->textBox12->Name = L"textBox12";
			this->textBox12->ReadOnly = true;
			this->textBox12->Size = System::Drawing::Size(41, 20);
			this->textBox12->TabIndex = 5;
			// 
			// textBox11
			// 
			this->textBox11->Location = System::Drawing::Point(79, 188);
			this->textBox11->Name = L"textBox11";
			this->textBox11->ReadOnly = true;
			this->textBox11->Size = System::Drawing::Size(41, 20);
			this->textBox11->TabIndex = 5;
			// 
			// textBox10
			// 
			this->textBox10->Location = System::Drawing::Point(79, 146);
			this->textBox10->Name = L"textBox10";
			this->textBox10->ReadOnly = true;
			this->textBox10->Size = System::Drawing::Size(41, 20);
			this->textBox10->TabIndex = 5;
			// 
			// textBox9
			// 
			this->textBox9->Location = System::Drawing::Point(79, 103);
			this->textBox9->Name = L"textBox9";
			this->textBox9->ReadOnly = true;
			this->textBox9->Size = System::Drawing::Size(41, 20);
			this->textBox9->TabIndex = 5;
			// 
			// textBox8
			// 
			this->textBox8->Location = System::Drawing::Point(79, 64);
			this->textBox8->Name = L"textBox8";
			this->textBox8->ReadOnly = true;
			this->textBox8->Size = System::Drawing::Size(41, 20);
			this->textBox8->TabIndex = 5;
			// 
			// textBox18
			// 
			this->textBox18->Location = System::Drawing::Point(138, 229);
			this->textBox18->Name = L"textBox18";
			this->textBox18->ReadOnly = true;
			this->textBox18->Size = System::Drawing::Size(41, 20);
			this->textBox18->TabIndex = 5;
			// 
			// textBox17
			// 
			this->textBox17->Location = System::Drawing::Point(138, 188);
			this->textBox17->Name = L"textBox17";
			this->textBox17->ReadOnly = true;
			this->textBox17->Size = System::Drawing::Size(41, 20);
			this->textBox17->TabIndex = 5;
			// 
			// textBox16
			// 
			this->textBox16->Location = System::Drawing::Point(138, 146);
			this->textBox16->Name = L"textBox16";
			this->textBox16->ReadOnly = true;
			this->textBox16->Size = System::Drawing::Size(41, 20);
			this->textBox16->TabIndex = 5;
			// 
			// textBox15
			// 
			this->textBox15->Location = System::Drawing::Point(138, 103);
			this->textBox15->Name = L"textBox15";
			this->textBox15->ReadOnly = true;
			this->textBox15->Size = System::Drawing::Size(41, 20);
			this->textBox15->TabIndex = 5;
			// 
			// textBox14
			// 
			this->textBox14->Location = System::Drawing::Point(138, 63);
			this->textBox14->Name = L"textBox14";
			this->textBox14->ReadOnly = true;
			this->textBox14->Size = System::Drawing::Size(41, 20);
			this->textBox14->TabIndex = 5;
			// 
			// textBox13
			// 
			this->textBox13->Location = System::Drawing::Point(138, 23);
			this->textBox13->Name = L"textBox13";
			this->textBox13->ReadOnly = true;
			this->textBox13->Size = System::Drawing::Size(41, 20);
			this->textBox13->TabIndex = 5;
			// 
			// textBox7
			// 
			this->textBox7->Location = System::Drawing::Point(79, 23);
			this->textBox7->Name = L"textBox7";
			this->textBox7->ReadOnly = true;
			this->textBox7->Size = System::Drawing::Size(41, 20);
			this->textBox7->TabIndex = 5;
			// 
			// charismaDropDown
			// 
			this->charismaDropDown->FormattingEnabled = true;
			this->charismaDropDown->Location = System::Drawing::Point(10, 229);
			this->charismaDropDown->Name = L"charismaDropDown";
			this->charismaDropDown->Size = System::Drawing::Size(44, 21);
			this->charismaDropDown->TabIndex = 4;
			this->charismaDropDown->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::wisdomDropDown_SelectedIndexChanged);
			// 
			// wisdomDropDown
			// 
			this->wisdomDropDown->FormattingEnabled = true;
			this->wisdomDropDown->Location = System::Drawing::Point(11, 188);
			this->wisdomDropDown->Name = L"wisdomDropDown";
			this->wisdomDropDown->Size = System::Drawing::Size(44, 21);
			this->wisdomDropDown->TabIndex = 4;
			this->wisdomDropDown->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::wisdomDropDown_SelectedIndexChanged);
			// 
			// intelligenceDropDown
			// 
			this->intelligenceDropDown->FormattingEnabled = true;
			this->intelligenceDropDown->Location = System::Drawing::Point(10, 146);
			this->intelligenceDropDown->Name = L"intelligenceDropDown";
			this->intelligenceDropDown->Size = System::Drawing::Size(44, 21);
			this->intelligenceDropDown->TabIndex = 4;
			// 
			// dexterityDropDown
			// 
			this->dexterityDropDown->FormattingEnabled = true;
			this->dexterityDropDown->Location = System::Drawing::Point(10, 103);
			this->dexterityDropDown->Name = L"dexterityDropDown";
			this->dexterityDropDown->Size = System::Drawing::Size(44, 21);
			this->dexterityDropDown->TabIndex = 4;
			// 
			// constitutionDropDown
			// 
			this->constitutionDropDown->FormattingEnabled = true;
			this->constitutionDropDown->Location = System::Drawing::Point(11, 63);
			this->constitutionDropDown->Name = L"constitutionDropDown";
			this->constitutionDropDown->Size = System::Drawing::Size(44, 21);
			this->constitutionDropDown->TabIndex = 4;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(7, 213);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(50, 13);
			this->label10->TabIndex = 0;
			this->label10->Text = L"Charisma";
			this->label10->Click += gcnew System::EventHandler(this, &MyForm::label9_Click);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(8, 172);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(45, 13);
			this->label9->TabIndex = 0;
			this->label9->Text = L"Wisdom";
			this->label9->Click += gcnew System::EventHandler(this, &MyForm::label9_Click);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(7, 130);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(61, 13);
			this->label8->TabIndex = 0;
			this->label8->Text = L"Intelligence";
			// 
			// strengthDropDown
			// 
			this->strengthDropDown->FormattingEnabled = true;
			this->strengthDropDown->Location = System::Drawing::Point(11, 23);
			this->strengthDropDown->Name = L"strengthDropDown";
			this->strengthDropDown->Size = System::Drawing::Size(44, 21);
			this->strengthDropDown->TabIndex = 4;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(7, 87);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(48, 13);
			this->label7->TabIndex = 0;
			this->label7->Text = L"Dexterity";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(135, 7);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(77, 13);
			this->label14->TabIndex = 0;
			this->label14->Text = L"Modifier + � lvl";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(8, 47);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(62, 13);
			this->label6->TabIndex = 0;
			this->label6->Text = L"Constitution";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(76, 7);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(44, 13);
			this->label11->TabIndex = 0;
			this->label11->Text = L"Modifier";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(8, 7);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(47, 13);
			this->label5->TabIndex = 0;
			this->label5->Text = L"Strength";
			// 
			// skillsPage
			// 
			this->skillsPage->Controls->Add(this->label34);
			this->skillsPage->Controls->Add(this->label21);
			this->skillsPage->Controls->Add(this->label19);
			this->skillsPage->Controls->Add(this->textBox49);
			this->skillsPage->Controls->Add(this->textBox50);
			this->skillsPage->Controls->Add(this->textBox51);
			this->skillsPage->Controls->Add(this->textBox52);
			this->skillsPage->Controls->Add(this->comboBox21);
			this->skillsPage->Controls->Add(this->comboBox22);
			this->skillsPage->Controls->Add(this->label32);
			this->skillsPage->Controls->Add(this->label33);
			this->skillsPage->Controls->Add(this->textBox45);
			this->skillsPage->Controls->Add(this->textBox46);
			this->skillsPage->Controls->Add(this->textBox47);
			this->skillsPage->Controls->Add(this->textBox48);
			this->skillsPage->Controls->Add(this->comboBox19);
			this->skillsPage->Controls->Add(this->comboBox20);
			this->skillsPage->Controls->Add(this->label30);
			this->skillsPage->Controls->Add(this->label31);
			this->skillsPage->Controls->Add(this->textBox41);
			this->skillsPage->Controls->Add(this->textBox42);
			this->skillsPage->Controls->Add(this->textBox43);
			this->skillsPage->Controls->Add(this->textBox44);
			this->skillsPage->Controls->Add(this->comboBox17);
			this->skillsPage->Controls->Add(this->comboBox18);
			this->skillsPage->Controls->Add(this->label28);
			this->skillsPage->Controls->Add(this->label29);
			this->skillsPage->Controls->Add(this->textBox31);
			this->skillsPage->Controls->Add(this->textBox32);
			this->skillsPage->Controls->Add(this->textBox33);
			this->skillsPage->Controls->Add(this->textBox34);
			this->skillsPage->Controls->Add(this->textBox35);
			this->skillsPage->Controls->Add(this->textBox36);
			this->skillsPage->Controls->Add(this->textBox37);
			this->skillsPage->Controls->Add(this->textBox38);
			this->skillsPage->Controls->Add(this->textBox39);
			this->skillsPage->Controls->Add(this->textBox40);
			this->skillsPage->Controls->Add(this->comboBox12);
			this->skillsPage->Controls->Add(this->comboBox13);
			this->skillsPage->Controls->Add(this->comboBox14);
			this->skillsPage->Controls->Add(this->comboBox15);
			this->skillsPage->Controls->Add(this->comboBox16);
			this->skillsPage->Controls->Add(this->label23);
			this->skillsPage->Controls->Add(this->label24);
			this->skillsPage->Controls->Add(this->label25);
			this->skillsPage->Controls->Add(this->label26);
			this->skillsPage->Controls->Add(this->label27);
			this->skillsPage->Controls->Add(this->textBox19);
			this->skillsPage->Controls->Add(this->textBox20);
			this->skillsPage->Controls->Add(this->textBox21);
			this->skillsPage->Controls->Add(this->textBox22);
			this->skillsPage->Controls->Add(this->textBox23);
			this->skillsPage->Controls->Add(this->textBox24);
			this->skillsPage->Controls->Add(this->textBox25);
			this->skillsPage->Controls->Add(this->textBox26);
			this->skillsPage->Controls->Add(this->textBox27);
			this->skillsPage->Controls->Add(this->textBox28);
			this->skillsPage->Controls->Add(this->textBox29);
			this->skillsPage->Controls->Add(this->textBox30);
			this->skillsPage->Controls->Add(this->comboBox6);
			this->skillsPage->Controls->Add(this->comboBox7);
			this->skillsPage->Controls->Add(this->comboBox8);
			this->skillsPage->Controls->Add(this->comboBox9);
			this->skillsPage->Controls->Add(this->comboBox10);
			this->skillsPage->Controls->Add(this->label15);
			this->skillsPage->Controls->Add(this->label16);
			this->skillsPage->Controls->Add(this->label17);
			this->skillsPage->Controls->Add(this->comboBox11);
			this->skillsPage->Controls->Add(this->label18);
			this->skillsPage->Controls->Add(this->modifierhalfmod);
			this->skillsPage->Controls->Add(this->label20);
			this->skillsPage->Controls->Add(this->label22);
			this->skillsPage->Location = System::Drawing::Point(4, 22);
			this->skillsPage->Name = L"skillsPage";
			this->skillsPage->Size = System::Drawing::Size(501, 562);
			this->skillsPage->TabIndex = 2;
			this->skillsPage->Text = L"Skills";
			this->skillsPage->UseVisualStyleBackColor = true;
			// 
			// textBox49
			// 
			this->textBox49->Location = System::Drawing::Point(342, 344);
			this->textBox49->Name = L"textBox49";
			this->textBox49->ReadOnly = true;
			this->textBox49->Size = System::Drawing::Size(41, 20);
			this->textBox49->TabIndex = 75;
			// 
			// textBox50
			// 
			this->textBox50->Location = System::Drawing::Point(342, 303);
			this->textBox50->Name = L"textBox50";
			this->textBox50->ReadOnly = true;
			this->textBox50->Size = System::Drawing::Size(41, 20);
			this->textBox50->TabIndex = 74;
			// 
			// textBox51
			// 
			this->textBox51->Location = System::Drawing::Point(401, 344);
			this->textBox51->Name = L"textBox51";
			this->textBox51->ReadOnly = true;
			this->textBox51->Size = System::Drawing::Size(41, 20);
			this->textBox51->TabIndex = 73;
			// 
			// textBox52
			// 
			this->textBox52->Location = System::Drawing::Point(401, 303);
			this->textBox52->Name = L"textBox52";
			this->textBox52->ReadOnly = true;
			this->textBox52->Size = System::Drawing::Size(41, 20);
			this->textBox52->TabIndex = 72;
			// 
			// comboBox21
			// 
			this->comboBox21->FormattingEnabled = true;
			this->comboBox21->Location = System::Drawing::Point(273, 344);
			this->comboBox21->Name = L"comboBox21";
			this->comboBox21->Size = System::Drawing::Size(44, 21);
			this->comboBox21->TabIndex = 71;
			// 
			// comboBox22
			// 
			this->comboBox22->FormattingEnabled = true;
			this->comboBox22->Location = System::Drawing::Point(274, 303);
			this->comboBox22->Name = L"comboBox22";
			this->comboBox22->Size = System::Drawing::Size(44, 21);
			this->comboBox22->TabIndex = 70;
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(270, 328);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(48, 13);
			this->label32->TabIndex = 69;
			this->label32->Text = L"Thievery";
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(271, 287);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(56, 13);
			this->label33->TabIndex = 68;
			this->label33->Text = L"Streetwise";
			// 
			// textBox45
			// 
			this->textBox45->Location = System::Drawing::Point(343, 260);
			this->textBox45->Name = L"textBox45";
			this->textBox45->ReadOnly = true;
			this->textBox45->Size = System::Drawing::Size(41, 20);
			this->textBox45->TabIndex = 67;
			// 
			// textBox46
			// 
			this->textBox46->Location = System::Drawing::Point(343, 219);
			this->textBox46->Name = L"textBox46";
			this->textBox46->ReadOnly = true;
			this->textBox46->Size = System::Drawing::Size(41, 20);
			this->textBox46->TabIndex = 66;
			// 
			// textBox47
			// 
			this->textBox47->Location = System::Drawing::Point(402, 260);
			this->textBox47->Name = L"textBox47";
			this->textBox47->ReadOnly = true;
			this->textBox47->Size = System::Drawing::Size(41, 20);
			this->textBox47->TabIndex = 65;
			// 
			// textBox48
			// 
			this->textBox48->Location = System::Drawing::Point(402, 219);
			this->textBox48->Name = L"textBox48";
			this->textBox48->ReadOnly = true;
			this->textBox48->Size = System::Drawing::Size(41, 20);
			this->textBox48->TabIndex = 64;
			// 
			// comboBox19
			// 
			this->comboBox19->FormattingEnabled = true;
			this->comboBox19->Location = System::Drawing::Point(274, 260);
			this->comboBox19->Name = L"comboBox19";
			this->comboBox19->Size = System::Drawing::Size(44, 21);
			this->comboBox19->TabIndex = 63;
			// 
			// comboBox20
			// 
			this->comboBox20->FormattingEnabled = true;
			this->comboBox20->Location = System::Drawing::Point(275, 219);
			this->comboBox20->Name = L"comboBox20";
			this->comboBox20->Size = System::Drawing::Size(44, 21);
			this->comboBox20->TabIndex = 62;
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(271, 244);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(40, 13);
			this->label30->TabIndex = 61;
			this->label30->Text = L"Stealth";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(272, 203);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(45, 13);
			this->label31->TabIndex = 60;
			this->label31->Text = L"Religion";
			// 
			// textBox41
			// 
			this->textBox41->Location = System::Drawing::Point(343, 179);
			this->textBox41->Name = L"textBox41";
			this->textBox41->ReadOnly = true;
			this->textBox41->Size = System::Drawing::Size(41, 20);
			this->textBox41->TabIndex = 59;
			// 
			// textBox42
			// 
			this->textBox42->Location = System::Drawing::Point(343, 138);
			this->textBox42->Name = L"textBox42";
			this->textBox42->ReadOnly = true;
			this->textBox42->Size = System::Drawing::Size(41, 20);
			this->textBox42->TabIndex = 58;
			// 
			// textBox43
			// 
			this->textBox43->Location = System::Drawing::Point(402, 179);
			this->textBox43->Name = L"textBox43";
			this->textBox43->ReadOnly = true;
			this->textBox43->Size = System::Drawing::Size(41, 20);
			this->textBox43->TabIndex = 57;
			// 
			// textBox44
			// 
			this->textBox44->Location = System::Drawing::Point(402, 138);
			this->textBox44->Name = L"textBox44";
			this->textBox44->ReadOnly = true;
			this->textBox44->Size = System::Drawing::Size(41, 20);
			this->textBox44->TabIndex = 56;
			// 
			// comboBox17
			// 
			this->comboBox17->FormattingEnabled = true;
			this->comboBox17->Location = System::Drawing::Point(274, 179);
			this->comboBox17->Name = L"comboBox17";
			this->comboBox17->Size = System::Drawing::Size(44, 21);
			this->comboBox17->TabIndex = 55;
			// 
			// comboBox18
			// 
			this->comboBox18->FormattingEnabled = true;
			this->comboBox18->Location = System::Drawing::Point(275, 138);
			this->comboBox18->Name = L"comboBox18";
			this->comboBox18->Size = System::Drawing::Size(44, 21);
			this->comboBox18->TabIndex = 54;
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(271, 163);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(58, 13);
			this->label28->TabIndex = 53;
			this->label28->Text = L"Perception";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(272, 122);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(39, 13);
			this->label29->TabIndex = 52;
			this->label29->Text = L"Nature";
			// 
			// textBox31
			// 
			this->textBox31->Location = System::Drawing::Point(343, 98);
			this->textBox31->Name = L"textBox31";
			this->textBox31->ReadOnly = true;
			this->textBox31->Size = System::Drawing::Size(41, 20);
			this->textBox31->TabIndex = 51;
			// 
			// textBox32
			// 
			this->textBox32->Location = System::Drawing::Point(343, 57);
			this->textBox32->Name = L"textBox32";
			this->textBox32->ReadOnly = true;
			this->textBox32->Size = System::Drawing::Size(41, 20);
			this->textBox32->TabIndex = 50;
			// 
			// textBox33
			// 
			this->textBox33->Location = System::Drawing::Point(78, 387);
			this->textBox33->Name = L"textBox33";
			this->textBox33->ReadOnly = true;
			this->textBox33->Size = System::Drawing::Size(41, 20);
			this->textBox33->TabIndex = 49;
			// 
			// textBox34
			// 
			this->textBox34->Location = System::Drawing::Point(78, 344);
			this->textBox34->Name = L"textBox34";
			this->textBox34->ReadOnly = true;
			this->textBox34->Size = System::Drawing::Size(41, 20);
			this->textBox34->TabIndex = 48;
			// 
			// textBox35
			// 
			this->textBox35->Location = System::Drawing::Point(78, 305);
			this->textBox35->Name = L"textBox35";
			this->textBox35->ReadOnly = true;
			this->textBox35->Size = System::Drawing::Size(41, 20);
			this->textBox35->TabIndex = 47;
			// 
			// textBox36
			// 
			this->textBox36->Location = System::Drawing::Point(402, 98);
			this->textBox36->Name = L"textBox36";
			this->textBox36->ReadOnly = true;
			this->textBox36->Size = System::Drawing::Size(41, 20);
			this->textBox36->TabIndex = 46;
			// 
			// textBox37
			// 
			this->textBox37->Location = System::Drawing::Point(402, 57);
			this->textBox37->Name = L"textBox37";
			this->textBox37->ReadOnly = true;
			this->textBox37->Size = System::Drawing::Size(41, 20);
			this->textBox37->TabIndex = 45;
			// 
			// textBox38
			// 
			this->textBox38->Location = System::Drawing::Point(137, 387);
			this->textBox38->Name = L"textBox38";
			this->textBox38->ReadOnly = true;
			this->textBox38->Size = System::Drawing::Size(41, 20);
			this->textBox38->TabIndex = 44;
			// 
			// textBox39
			// 
			this->textBox39->Location = System::Drawing::Point(137, 344);
			this->textBox39->Name = L"textBox39";
			this->textBox39->ReadOnly = true;
			this->textBox39->Size = System::Drawing::Size(41, 20);
			this->textBox39->TabIndex = 43;
			// 
			// textBox40
			// 
			this->textBox40->Location = System::Drawing::Point(137, 304);
			this->textBox40->Name = L"textBox40";
			this->textBox40->ReadOnly = true;
			this->textBox40->Size = System::Drawing::Size(41, 20);
			this->textBox40->TabIndex = 42;
			// 
			// comboBox12
			// 
			this->comboBox12->FormattingEnabled = true;
			this->comboBox12->Location = System::Drawing::Point(274, 98);
			this->comboBox12->Name = L"comboBox12";
			this->comboBox12->Size = System::Drawing::Size(44, 21);
			this->comboBox12->TabIndex = 41;
			// 
			// comboBox13
			// 
			this->comboBox13->FormattingEnabled = true;
			this->comboBox13->Location = System::Drawing::Point(275, 57);
			this->comboBox13->Name = L"comboBox13";
			this->comboBox13->Size = System::Drawing::Size(44, 21);
			this->comboBox13->TabIndex = 40;
			// 
			// comboBox14
			// 
			this->comboBox14->FormattingEnabled = true;
			this->comboBox14->Location = System::Drawing::Point(9, 387);
			this->comboBox14->Name = L"comboBox14";
			this->comboBox14->Size = System::Drawing::Size(44, 21);
			this->comboBox14->TabIndex = 39;
			// 
			// comboBox15
			// 
			this->comboBox15->FormattingEnabled = true;
			this->comboBox15->Location = System::Drawing::Point(9, 344);
			this->comboBox15->Name = L"comboBox15";
			this->comboBox15->Size = System::Drawing::Size(44, 21);
			this->comboBox15->TabIndex = 38;
			// 
			// comboBox16
			// 
			this->comboBox16->FormattingEnabled = true;
			this->comboBox16->Location = System::Drawing::Point(10, 304);
			this->comboBox16->Name = L"comboBox16";
			this->comboBox16->Size = System::Drawing::Size(44, 21);
			this->comboBox16->TabIndex = 37;
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(271, 82);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(52, 13);
			this->label23->TabIndex = 36;
			this->label23->Text = L"Intimidate";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(272, 41);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(38, 13);
			this->label24->TabIndex = 35;
			this->label24->Text = L"Insight";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(6, 371);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(39, 13);
			this->label25->TabIndex = 34;
			this->label25->Text = L"History";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(6, 328);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(29, 13);
			this->label26->TabIndex = 33;
			this->label26->Text = L"Heal";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(7, 288);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(59, 13);
			this->label27->TabIndex = 32;
			this->label27->Text = L"Endurance";
			// 
			// textBox19
			// 
			this->textBox19->Location = System::Drawing::Point(78, 264);
			this->textBox19->Name = L"textBox19";
			this->textBox19->ReadOnly = true;
			this->textBox19->Size = System::Drawing::Size(41, 20);
			this->textBox19->TabIndex = 31;
			// 
			// textBox20
			// 
			this->textBox20->Location = System::Drawing::Point(78, 223);
			this->textBox20->Name = L"textBox20";
			this->textBox20->ReadOnly = true;
			this->textBox20->Size = System::Drawing::Size(41, 20);
			this->textBox20->TabIndex = 29;
			// 
			// textBox21
			// 
			this->textBox21->Location = System::Drawing::Point(78, 181);
			this->textBox21->Name = L"textBox21";
			this->textBox21->ReadOnly = true;
			this->textBox21->Size = System::Drawing::Size(41, 20);
			this->textBox21->TabIndex = 28;
			// 
			// textBox22
			// 
			this->textBox22->Location = System::Drawing::Point(78, 138);
			this->textBox22->Name = L"textBox22";
			this->textBox22->ReadOnly = true;
			this->textBox22->Size = System::Drawing::Size(41, 20);
			this->textBox22->TabIndex = 27;
			// 
			// textBox23
			// 
			this->textBox23->Location = System::Drawing::Point(78, 99);
			this->textBox23->Name = L"textBox23";
			this->textBox23->ReadOnly = true;
			this->textBox23->Size = System::Drawing::Size(41, 20);
			this->textBox23->TabIndex = 26;
			// 
			// textBox24
			// 
			this->textBox24->Location = System::Drawing::Point(137, 264);
			this->textBox24->Name = L"textBox24";
			this->textBox24->ReadOnly = true;
			this->textBox24->Size = System::Drawing::Size(41, 20);
			this->textBox24->TabIndex = 25;
			// 
			// textBox25
			// 
			this->textBox25->Location = System::Drawing::Point(137, 223);
			this->textBox25->Name = L"textBox25";
			this->textBox25->ReadOnly = true;
			this->textBox25->Size = System::Drawing::Size(41, 20);
			this->textBox25->TabIndex = 24;
			// 
			// textBox26
			// 
			this->textBox26->Location = System::Drawing::Point(137, 181);
			this->textBox26->Name = L"textBox26";
			this->textBox26->ReadOnly = true;
			this->textBox26->Size = System::Drawing::Size(41, 20);
			this->textBox26->TabIndex = 23;
			// 
			// textBox27
			// 
			this->textBox27->Location = System::Drawing::Point(137, 138);
			this->textBox27->Name = L"textBox27";
			this->textBox27->ReadOnly = true;
			this->textBox27->Size = System::Drawing::Size(41, 20);
			this->textBox27->TabIndex = 22;
			// 
			// textBox28
			// 
			this->textBox28->Location = System::Drawing::Point(137, 98);
			this->textBox28->Name = L"textBox28";
			this->textBox28->ReadOnly = true;
			this->textBox28->Size = System::Drawing::Size(41, 20);
			this->textBox28->TabIndex = 21;
			// 
			// textBox29
			// 
			this->textBox29->Location = System::Drawing::Point(137, 58);
			this->textBox29->Name = L"textBox29";
			this->textBox29->ReadOnly = true;
			this->textBox29->Size = System::Drawing::Size(41, 20);
			this->textBox29->TabIndex = 20;
			// 
			// textBox30
			// 
			this->textBox30->Location = System::Drawing::Point(78, 58);
			this->textBox30->Name = L"textBox30";
			this->textBox30->ReadOnly = true;
			this->textBox30->Size = System::Drawing::Size(41, 20);
			this->textBox30->TabIndex = 30;
			// 
			// comboBox6
			// 
			this->comboBox6->FormattingEnabled = true;
			this->comboBox6->Location = System::Drawing::Point(9, 264);
			this->comboBox6->Name = L"comboBox6";
			this->comboBox6->Size = System::Drawing::Size(44, 21);
			this->comboBox6->TabIndex = 19;
			// 
			// comboBox7
			// 
			this->comboBox7->FormattingEnabled = true;
			this->comboBox7->Location = System::Drawing::Point(10, 223);
			this->comboBox7->Name = L"comboBox7";
			this->comboBox7->Size = System::Drawing::Size(44, 21);
			this->comboBox7->TabIndex = 18;
			// 
			// comboBox8
			// 
			this->comboBox8->FormattingEnabled = true;
			this->comboBox8->Location = System::Drawing::Point(9, 181);
			this->comboBox8->Name = L"comboBox8";
			this->comboBox8->Size = System::Drawing::Size(44, 21);
			this->comboBox8->TabIndex = 17;
			// 
			// comboBox9
			// 
			this->comboBox9->FormattingEnabled = true;
			this->comboBox9->Location = System::Drawing::Point(9, 138);
			this->comboBox9->Name = L"comboBox9";
			this->comboBox9->Size = System::Drawing::Size(44, 21);
			this->comboBox9->TabIndex = 16;
			// 
			// comboBox10
			// 
			this->comboBox10->FormattingEnabled = true;
			this->comboBox10->Location = System::Drawing::Point(10, 98);
			this->comboBox10->Name = L"comboBox10";
			this->comboBox10->Size = System::Drawing::Size(44, 21);
			this->comboBox10->TabIndex = 15;
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(6, 248);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(80, 13);
			this->label15->TabIndex = 12;
			this->label15->Text = L"Dungeoneering";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(7, 207);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(56, 13);
			this->label16->TabIndex = 11;
			this->label16->Text = L"Diplomacy";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(6, 165);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(28, 13);
			this->label17->TabIndex = 10;
			this->label17->Text = L"Bluff";
			// 
			// comboBox11
			// 
			this->comboBox11->FormattingEnabled = true;
			this->comboBox11->Location = System::Drawing::Point(10, 58);
			this->comboBox11->Name = L"comboBox11";
			this->comboBox11->Size = System::Drawing::Size(44, 21);
			this->comboBox11->TabIndex = 14;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(6, 122);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(47, 13);
			this->label18->TabIndex = 9;
			this->label18->Text = L"Athletics";
			// 
			// modifierhalfmod
			// 
			this->modifierhalfmod->AutoSize = true;
			this->modifierhalfmod->Location = System::Drawing::Point(75, 29);
			this->modifierhalfmod->Name = L"modifierhalfmod";
			this->modifierhalfmod->Size = System::Drawing::Size(47, 26);
			this->modifierhalfmod->TabIndex = 8;
			this->modifierhalfmod->Text = L"Modifier \n+ � lvl";
			this->modifierhalfmod->Click += gcnew System::EventHandler(this, &MyForm::label19_Click);
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(7, 82);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(41, 13);
			this->label20->TabIndex = 7;
			this->label20->Text = L"Arcana";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(7, 42);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(57, 13);
			this->label22->TabIndex = 6;
			this->label22->Text = L"Acrobatics";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(340, 28);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(47, 26);
			this->label19->TabIndex = 76;
			this->label19->Text = L"Modifier \n+ � lvl";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(134, 42);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(29, 13);
			this->label21->TabIndex = 77;
			this->label21->Text = L"Misc";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(399, 41);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(29, 13);
			this->label34->TabIndex = 78;
			this->label34->Text = L"Misc";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(510, 586);
			this->Controls->Add(this->tabControl1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->tabControl1->ResumeLayout(false);
			this->generalPage->ResumeLayout(false);
			this->generalPage->PerformLayout();
			this->statsPage->ResumeLayout(false);
			this->statsPage->PerformLayout();
			this->skillsPage->ResumeLayout(false);
			this->skillsPage->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void tabPage1_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void classDropDown_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void raceDropDown_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void sizeBox_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void wisdomDropDown_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label9_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void label19_Click(System::Object^  sender, System::EventArgs^  e) {
}
};
}
