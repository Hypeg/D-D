#include "Dungeons_And_Dragons_Data_Sheet.h"

using namespace System;
using namespace System::Windows::Forms;
[STAThread]
void main(array<String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	DADDataSheet::Dungeons_And_Dragons_Data_Sheet form;
	Application::Run(%form);
}