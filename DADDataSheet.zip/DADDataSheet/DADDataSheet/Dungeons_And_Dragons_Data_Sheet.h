#pragma once

namespace DADDataSheet {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Dungeons_And_Dragons_Data_Sheet
	/// </summary>
	public ref class Dungeons_And_Dragons_Data_Sheet : public System::Windows::Forms::Form
	{
	public:
		Dungeons_And_Dragons_Data_Sheet(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Dungeons_And_Dragons_Data_Sheet()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::ComboBox^  CharacterRace;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  button2;


	private: System::Windows::Forms::Label^  label3;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::ComboBox^  comboBox2;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Dungeons_And_Dragons_Data_Sheet::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->CharacterRace = (gcnew System::Windows::Forms::ComboBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(840, 464);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Save";
			this->button1->UseVisualStyleBackColor = true;
			// 
			// CharacterRace
			// 
			this->CharacterRace->FormattingEnabled = true;
			this->CharacterRace->Items->AddRange(gcnew cli::array< System::Object^  >(8) {
				L"Dragonborn", L"Dwarf", L"Eladrin", L"Elf",
					L"Half-Elf", L"Halfing", L"Human", L"Tiefling"
			});
			this->CharacterRace->Location = System::Drawing::Point(31, 96);
			this->CharacterRace->Name = L"CharacterRace";
			this->CharacterRace->Size = System::Drawing::Size(214, 21);
			this->CharacterRace->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Location = System::Drawing::Point(100, 80);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(82, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Character Race";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(31, 57);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(214, 20);
			this->textBox1->TabIndex = 3;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Location = System::Drawing::Point(123, 41);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(35, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Name";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(759, 464);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 5;
			this->button2->Text = L"Exit";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Location = System::Drawing::Point(120, 120);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(38, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Height";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Location = System::Drawing::Point(117, 159);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(41, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"Weight";
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(49) {
				L"3\'", L"3\'1", L"3\'2", L"3\'3", L"3\'4", L"3\'5",
					L"3\'6", L"3\'7", L"3\'8", L"3\'9", L"3\'10", L"3\'11", L"4\'", L"4\'1", L"4\'2", L"4\'3", L"4\'4", L"4\'5", L"4\'6", L"4\'7",
					L"4\'8", L"4\'9", L"4\'10", L"4\'11", L"5\'", L"5\'1", L"5\'2", L"5\'3", L"5\'4", L"5\'5", L"5\'6", L"5\'7", L"5\'8", L"5\'9",
					L"5\'10", L"5\'11", L"6\'", L"6\'1", L"6\'2", L"6\'3", L"6\'4", L"6\'5", L"6\'6", L"6\'7", L"6\'8", L"6\'9", L"6\'10", L"6\'11",
					L"7\'"
			});
			this->comboBox1->Location = System::Drawing::Point(31, 136);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(214, 21);
			this->comboBox1->TabIndex = 10;
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(51) {
				L"70", L"75", L"80", L"85", L"90", L"95", L"100",
					L"105", L"110", L"115", L"120", L"125", L"130", L"135", L"140", L"145", L"150", L"155", L"160", L"165", L"170", L"175", L"180",
					L"185", L"190", L"195", L"200", L"205", L"210", L"215", L"220", L"225", L"230", L"235", L"240", L"245", L"250", L"255", L"260",
					L"265", L"270", L"275", L"280", L"285", L"290", L"295", L"300", L"305", L"310", L"315", L"320"
			});
			this->comboBox2->Location = System::Drawing::Point(31, 175);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(214, 21);
			this->comboBox2->TabIndex = 11;
			// 
			// Dungeons_And_Dragons_Data_Sheet
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(927, 499);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->CharacterRace);
			this->Controls->Add(this->button1);
			this->Name = L"Dungeons_And_Dragons_Data_Sheet";
			this->Text = L"Dungeons_And_Dragons_Data_Sheet";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}
